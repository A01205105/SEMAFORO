#include "hal_data.h"

const bsp_delay_units_t bsp_delay_units = BSP_DELAY_UNITS_MILLISECONDS;     /* Define the units to be used with the software delay function */
uint32_t car = 0;
uint32_t person = 0;
uint32_t flag = 0;

void hal_entry(void) {

    g_external_irq10.p_api->open(g_external_irq10.p_ctrl,g_external_irq10.p_cfg);
    g_external_irq11.p_api->open(g_external_irq11.p_ctrl,g_external_irq11.p_cfg);

    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);

    while(1)
    {
    	if(car == 0 && person == 0){
    		if(flag == 1){
    			R_BSP_SoftwareDelay(5000, bsp_delay_units);
    			flag = 0;
    		}
    	}

    	if(car == 1 || person == 1){
    		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);

    		flashYellowLight();

    		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_LOW);
    		if(car == 1){
    			R_BSP_SoftwareDelay(2000, bsp_delay_units);
    		}else{
    			R_BSP_SoftwareDelay(4000, bsp_delay_units);
    		}

    		flashYellowLight();

    		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH);
    		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);

    		car = 0;
    		person = 0;
    		flag = 1;
    	}
    }
}

void button_callback_SW4(external_irq_callback_args_t *p_args){
    if(car == 0 && person == 0){
    	car = 1;
    }
}

void button_callback_SW5(external_irq_callback_args_t *p_args){
	if(car == 0 && person == 0){
		person = 1;
	}
}

void flashYellowLight(){
	uint32_t counter = 0;
	while(counter < 5){
		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_LOW);
		R_BSP_SoftwareDelay(500, bsp_delay_units);
		g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);
		R_BSP_SoftwareDelay(500, bsp_delay_units);
		counter++;
	}
}
